--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.2
-- Dumped by pg_dump version 12.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE klumba;
--
-- Name: klumba; Type: DATABASE; Schema: -; Owner: db
--

CREATE DATABASE klumba WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.utf8' LC_CTYPE = 'en_US.utf8';


ALTER DATABASE klumba OWNER TO db;

\connect klumba

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: db
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO db;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: db
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: us_colors; Type: DOMAIN; Schema: public; Owner: db
--

CREATE DOMAIN public.us_colors AS text[]
	CONSTRAINT us_colors_check CHECK ((VALUE <@ ARRAY['red'::text, 'white'::text]));


ALTER DOMAIN public.us_colors OWNER TO db;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: additional_products; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.additional_products (
    id integer NOT NULL,
    city_id integer,
    public boolean DEFAULT true,
    title character varying(200) NOT NULL,
    "desc" text NOT NULL,
    price integer NOT NULL,
    image character varying(255) NOT NULL
);


ALTER TABLE public.additional_products OWNER TO db;

--
-- Name: additional_products_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.additional_products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.additional_products_id_seq OWNER TO db;

--
-- Name: additional_products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.additional_products_id_seq OWNED BY public.additional_products.id;


--
-- Name: additives; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.additives (
    id integer NOT NULL,
    city_id integer,
    public boolean,
    "order" integer,
    title character varying(255),
    data json
);


ALTER TABLE public.additives OWNER TO db;

--
-- Name: additives_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.additives_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.additives_id_seq OWNER TO db;

--
-- Name: additives_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.additives_id_seq OWNED BY public.additives.id;


--
-- Name: banners; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.banners (
    id integer NOT NULL,
    city_id integer,
    public boolean,
    "order" integer,
    title character varying(300),
    images text[]
);


ALTER TABLE public.banners OWNER TO db;

--
-- Name: banners_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.banners_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.banners_id_seq OWNER TO db;

--
-- Name: banners_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.banners_id_seq OWNED BY public.banners.id;


--
-- Name: cities; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.cities (
    id integer NOT NULL,
    public boolean DEFAULT true,
    eng character varying(200) NOT NULL,
    rus character varying(200) NOT NULL,
    contacts json,
    extra json
);


ALTER TABLE public.cities OWNER TO db;

--
-- Name: cities_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.cities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cities_id_seq OWNER TO db;

--
-- Name: cities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.cities_id_seq OWNED BY public.cities.id;


--
-- Name: content; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.content (
    id integer NOT NULL,
    city_id integer,
    public boolean,
    "order" integer,
    title character varying(300) NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.content OWNER TO db;

--
-- Name: content_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.content_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.content_id_seq OWNER TO db;

--
-- Name: content_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.content_id_seq OWNED BY public.content.id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    city_id integer,
    phone character varying(100) NOT NULL,
    name character varying(200) NOT NULL,
    points integer DEFAULT 0
);


ALTER TABLE public.customers OWNER TO db;

--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customers_id_seq OWNER TO db;

--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: entities; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.entities (
    id integer NOT NULL,
    "eType" character varying(255) NOT NULL,
    "eTypeTitle" character varying(255) NOT NULL,
    value character varying(255) NOT NULL,
    extra json
);


ALTER TABLE public.entities OWNER TO db;

--
-- Name: entities_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.entities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.entities_id_seq OWNER TO db;

--
-- Name: entities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.entities_id_seq OWNED BY public.entities.id;


--
-- Name: knex_migrations; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.knex_migrations (
    id integer NOT NULL,
    name character varying(255),
    batch integer,
    migration_time timestamp with time zone
);


ALTER TABLE public.knex_migrations OWNER TO db;

--
-- Name: knex_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.knex_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.knex_migrations_id_seq OWNER TO db;

--
-- Name: knex_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.knex_migrations_id_seq OWNED BY public.knex_migrations.id;


--
-- Name: knex_migrations_lock; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.knex_migrations_lock (
    index integer NOT NULL,
    is_locked integer
);


ALTER TABLE public.knex_migrations_lock OWNER TO db;

--
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.knex_migrations_lock_index_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.knex_migrations_lock_index_seq OWNER TO db;

--
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.knex_migrations_lock_index_seq OWNED BY public.knex_migrations_lock.index;


--
-- Name: product_sizes; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.product_sizes (
    id integer NOT NULL,
    city_id integer,
    product_id integer,
    public boolean,
    fast boolean,
    "order" integer,
    title character varying(200) NOT NULL,
    price integer NOT NULL,
    diameter integer NOT NULL,
    flowers integer[],
    flowers_counts integer[],
    images text[]
);


ALTER TABLE public.product_sizes OWNER TO db;

--
-- Name: product_sizes_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.product_sizes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_sizes_id_seq OWNER TO db;

--
-- Name: product_sizes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.product_sizes_id_seq OWNED BY public.product_sizes.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.products (
    id integer NOT NULL,
    city_id integer,
    public boolean,
    "order" integer,
    slug character varying(400) NOT NULL,
    title character varying(200) NOT NULL,
    description character varying(1000),
    florist_id integer,
    florist_text character varying(1000),
    color character varying(50),
    stability character varying(50),
    shade character varying(50),
    packing character varying(50),
    "bouquetType" character varying(50),
    "additionalProducts" integer[]
);


ALTER TABLE public.products OWNER TO db;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_id_seq OWNER TO db;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: promo_codes; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.promo_codes (
    id integer NOT NULL,
    city_id integer,
    public boolean,
    code character varying(100) NOT NULL,
    code_type text NOT NULL,
    start timestamp with time zone NOT NULL,
    "end" timestamp with time zone NOT NULL,
    counter integer DEFAULT 0,
    CONSTRAINT promo_codes_code_type_check CHECK ((code_type = ANY (ARRAY['percent'::text, 'money'::text])))
);


ALTER TABLE public.promo_codes OWNER TO db;

--
-- Name: promo_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.promo_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.promo_codes_id_seq OWNER TO db;

--
-- Name: promo_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.promo_codes_id_seq OWNED BY public.promo_codes.id;


--
-- Name: reviews; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.reviews (
    id integer NOT NULL,
    city_id integer,
    public boolean DEFAULT false,
    "order" integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    name character varying(200),
    telegram character varying(200),
    instagram character varying(200),
    text character varying(5000) NOT NULL
);


ALTER TABLE public.reviews OWNER TO db;

--
-- Name: reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.reviews_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reviews_id_seq OWNER TO db;

--
-- Name: reviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.reviews_id_seq OWNED BY public.reviews.id;


--
-- Name: team; Type: TABLE; Schema: public; Owner: db
--

CREATE TABLE public.team (
    id integer NOT NULL,
    city_id integer,
    public boolean,
    "order" integer,
    "isFlorist" boolean,
    rule character varying(255),
    name character varying(400) NOT NULL,
    photo character varying(255) NOT NULL,
    instagram character varying(255),
    extra json
);


ALTER TABLE public.team OWNER TO db;

--
-- Name: team_id_seq; Type: SEQUENCE; Schema: public; Owner: db
--

CREATE SEQUENCE public.team_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.team_id_seq OWNER TO db;

--
-- Name: team_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db
--

ALTER SEQUENCE public.team_id_seq OWNED BY public.team.id;


--
-- Name: additional_products id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.additional_products ALTER COLUMN id SET DEFAULT nextval('public.additional_products_id_seq'::regclass);


--
-- Name: additives id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.additives ALTER COLUMN id SET DEFAULT nextval('public.additives_id_seq'::regclass);


--
-- Name: banners id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.banners ALTER COLUMN id SET DEFAULT nextval('public.banners_id_seq'::regclass);


--
-- Name: cities id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.cities ALTER COLUMN id SET DEFAULT nextval('public.cities_id_seq'::regclass);


--
-- Name: content id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.content ALTER COLUMN id SET DEFAULT nextval('public.content_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: entities id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.entities ALTER COLUMN id SET DEFAULT nextval('public.entities_id_seq'::regclass);


--
-- Name: knex_migrations id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.knex_migrations ALTER COLUMN id SET DEFAULT nextval('public.knex_migrations_id_seq'::regclass);


--
-- Name: knex_migrations_lock index; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.knex_migrations_lock ALTER COLUMN index SET DEFAULT nextval('public.knex_migrations_lock_index_seq'::regclass);


--
-- Name: product_sizes id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.product_sizes ALTER COLUMN id SET DEFAULT nextval('public.product_sizes_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: promo_codes id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.promo_codes ALTER COLUMN id SET DEFAULT nextval('public.promo_codes_id_seq'::regclass);


--
-- Name: reviews id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.reviews ALTER COLUMN id SET DEFAULT nextval('public.reviews_id_seq'::regclass);


--
-- Name: team id; Type: DEFAULT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.team ALTER COLUMN id SET DEFAULT nextval('public.team_id_seq'::regclass);


--
-- Data for Name: additional_products; Type: TABLE DATA; Schema: public; Owner: db
--

\i $$PATH$$/3072.dat

--
-- Data for Name: additives; Type: TABLE DATA; Schema: public; Owner: db
--

\i $$PATH$$/3099.dat

--
-- Data for Name: banners; Type: TABLE DATA; Schema: public; Owner: db
--

\i $$PATH$$/3093.dat

--
-- Data for Name: cities; Type: TABLE DATA; Schema: public; Owner: db
--

\i $$PATH$$/3074.dat

--
-- Data for Name: content; Type: TABLE DATA; Schema: public; Owner: db
--

\i $$PATH$$/3095.dat

--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: db
--

\i $$PATH$$/3076.dat

--
-- Data for Name: entities; Type: TABLE DATA; Schema: public; Owner: db
--

\i $$PATH$$/3078.dat

--
-- Data for Name: knex_migrations; Type: TABLE DATA; Schema: public; Owner: db
--

\i $$PATH$$/3080.dat

--
-- Data for Name: knex_migrations_lock; Type: TABLE DATA; Schema: public; Owner: db
--

\i $$PATH$$/3082.dat

--
-- Data for Name: product_sizes; Type: TABLE DATA; Schema: public; Owner: db
--

\i $$PATH$$/3091.dat

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: db
--

\i $$PATH$$/3089.dat

--
-- Data for Name: promo_codes; Type: TABLE DATA; Schema: public; Owner: db
--

\i $$PATH$$/3084.dat

--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: db
--

\i $$PATH$$/3097.dat

--
-- Data for Name: team; Type: TABLE DATA; Schema: public; Owner: db
--

\i $$PATH$$/3086.dat

--
-- Name: additional_products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.additional_products_id_seq', 1, false);


--
-- Name: additives_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.additives_id_seq', 19, true);


--
-- Name: banners_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.banners_id_seq', 10, true);


--
-- Name: cities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.cities_id_seq', 1, false);


--
-- Name: content_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.content_id_seq', 6, true);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.customers_id_seq', 1, false);


--
-- Name: entities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.entities_id_seq', 79, true);


--
-- Name: knex_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.knex_migrations_id_seq', 40, true);


--
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.knex_migrations_lock_index_seq', 1, true);


--
-- Name: product_sizes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.product_sizes_id_seq', 48, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.products_id_seq', 81, true);


--
-- Name: promo_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.promo_codes_id_seq', 1, false);


--
-- Name: reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.reviews_id_seq', 6, true);


--
-- Name: team_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db
--

SELECT pg_catalog.setval('public.team_id_seq', 20, true);


--
-- Name: additional_products additional_products_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.additional_products
    ADD CONSTRAINT additional_products_pkey PRIMARY KEY (id);


--
-- Name: additives additives_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.additives
    ADD CONSTRAINT additives_pkey PRIMARY KEY (id);


--
-- Name: banners banners_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.banners
    ADD CONSTRAINT banners_pkey PRIMARY KEY (id);


--
-- Name: cities cities_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.cities
    ADD CONSTRAINT cities_pkey PRIMARY KEY (id);


--
-- Name: content content_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.content
    ADD CONSTRAINT content_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: entities entities_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.entities
    ADD CONSTRAINT entities_pkey PRIMARY KEY (id);


--
-- Name: knex_migrations_lock knex_migrations_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.knex_migrations_lock
    ADD CONSTRAINT knex_migrations_lock_pkey PRIMARY KEY (index);


--
-- Name: knex_migrations knex_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.knex_migrations
    ADD CONSTRAINT knex_migrations_pkey PRIMARY KEY (id);


--
-- Name: product_sizes product_sizes_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.product_sizes
    ADD CONSTRAINT product_sizes_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: promo_codes promo_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.promo_codes
    ADD CONSTRAINT promo_codes_pkey PRIMARY KEY (id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: team team_pkey; Type: CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.team
    ADD CONSTRAINT team_pkey PRIMARY KEY (id);


--
-- Name: additional_products additional_products_city_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.additional_products
    ADD CONSTRAINT additional_products_city_id_foreign FOREIGN KEY (city_id) REFERENCES public.cities(id);


--
-- Name: additives additives_city_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.additives
    ADD CONSTRAINT additives_city_id_foreign FOREIGN KEY (city_id) REFERENCES public.cities(id);


--
-- Name: banners banners_city_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.banners
    ADD CONSTRAINT banners_city_id_foreign FOREIGN KEY (city_id) REFERENCES public.cities(id);


--
-- Name: content content_city_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.content
    ADD CONSTRAINT content_city_id_foreign FOREIGN KEY (city_id) REFERENCES public.cities(id);


--
-- Name: customers customers_city_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_city_id_foreign FOREIGN KEY (city_id) REFERENCES public.cities(id);


--
-- Name: product_sizes product_sizes_city_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.product_sizes
    ADD CONSTRAINT product_sizes_city_id_foreign FOREIGN KEY (city_id) REFERENCES public.cities(id);


--
-- Name: product_sizes product_sizes_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.product_sizes
    ADD CONSTRAINT product_sizes_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: products products_city_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_city_id_foreign FOREIGN KEY (city_id) REFERENCES public.cities(id);


--
-- Name: products products_florist_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_florist_id_foreign FOREIGN KEY (florist_id) REFERENCES public.team(id);


--
-- Name: promo_codes promo_codes_city_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.promo_codes
    ADD CONSTRAINT promo_codes_city_id_foreign FOREIGN KEY (city_id) REFERENCES public.cities(id);


--
-- Name: reviews reviews_city_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_city_id_foreign FOREIGN KEY (city_id) REFERENCES public.cities(id);


--
-- Name: team team_city_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: db
--

ALTER TABLE ONLY public.team
    ADD CONSTRAINT team_city_id_foreign FOREIGN KEY (city_id) REFERENCES public.cities(id);


--
-- PostgreSQL database dump complete
--

